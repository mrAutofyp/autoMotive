import React from "react";

import AppRouter from "../config/routes";
export default function App() {
  return (
    <div>
      <AppRouter />
    </div>
  );
}
