import React, { useEffect } from "react";
import { connect } from "react-redux";
import { get_All_Products, check_current_user } from "../store/action/action";
import Header from "../components/Header";
// import firebase from "../config/firebase";
function Home(props) {
  useEffect(() => {
    // props.get_All_Products();
    props.check_current_user();
  }, []);

  return (
    <div>
      <h1>{props.currentuser ? props.currentuser.displayName : null}</h1>
      <div className="section">
        <h1>All Products</h1>
        <div className="products-container">
          {props.allProducts.length ? (
            props.allProducts.map((v, i) => {
              return (
                <div key={i} className="products-card" id={v.key}>
                  <img src={v.img} alt="" />
                  <div className="product-card-details">
                    <h1 key={i}>{v.brand}</h1>
                    <h3>{v.title}</h3>
                    <h4>{v.price}</h4>
                    <p>{v.description}</p>
                    <button onClick={() => console.log("added to cart")}>
                      Add to cart
                    </button>
                  </div>
                </div>
              );
            })
          ) : (
            <h1>Loading....</h1>
          )}
        </div>
      </div>
    </div>
  );
}

const mapStateToProps = (store) => ({
  allProducts: store.allProducts,
  currentuser: store.currentuser,
});

const mapDispatchToProps = (dispatch) => ({
  get_All_Products: () => dispatch(get_All_Products()),
  check_current_user: () => dispatch(check_current_user()),
});

export default connect(mapStateToProps, mapDispatchToProps)(Home);
