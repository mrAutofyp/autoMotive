import React from "react";
import Header from "../components/Header";

export default function Shop() {
  return (
    <div>
      <h1>Shop</h1>
    </div>
  );
}
