import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "../assets/css/header.css";
import FormModel from "../components/FormModel";
import CloseIcon from "@material-ui/icons/Close";
import EditOutlinedIcon from "@material-ui/icons/EditOutlined";
import { connect } from "react-redux";
import firebase from "../config/firebase";
import defaultuserimg from "../assets/images/no-image.jpg";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
  useRouteMatch,
} from "react-router-dom";
import { withRouter } from "react-router-dom";
const Header = (props) => {
  var user = firebase.auth().currentUser;
  let match = useRouteMatch();
  const [successMsg, setsuccessMsg] = useState(false);
  const [open, setOpen] = useState(false);
  const [userProfile, setUserProfile] = useState(false);

  // const { location } = props;
  // if (location.pathname.match(/routeOnWhichToHideIt/)) {
  //   return console.log("hhhhhhhh");
  // }

  const handleClickOpen = () => {
    if (open === false) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  };

  const showLoginSucces = () => {
    setsuccessMsg(true);
  };

  const closeLoginSucces = () => {
    setsuccessMsg(false);
  };

  const signOut = () => {
    handleClickOpen();
    console.log("log out");
    firebase
      .auth()
      .signOut()
      .then(() => {
        console.log("successfully signout");
        setUserProfile(false);
        // setAdmin(false);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const changeInPaths = () => {
    setOpen(false);
  };
  return (
    <>
      {props.location.pathname &&
      props.history.location.pathname !== "/AdminDashboard" ? (
        <>
          {console.log(match.path, match.url)}
          <nav className="navbar">
            <h1>Logo</h1>
            <ul>
              {user ? (
                props.currentuser.admin ? (
                  <>
                    <li>
                      <Link onClick={changeInPaths} to="/AdminDashboard">
                        Dashboard
                      </Link>
                    </li>
                  </>
                ) : null
              ) : null}

              <li>
                <Link onClick={changeInPaths} to="/Home">
                  Home
                </Link>
              </li>
              <li>
                <Link onClick={changeInPaths} to="/Shop">
                  Shop
                </Link>
              </li>
              <li>
                <Link onClick={changeInPaths} to="/Contact">
                  Contact
                </Link>
              </li>
              {user ? (
                <>
                  <li>
                    <a onClick={handleClickOpen}>Profile</a>
                  </li>
                  {open ? <UserprofileDropDown logout={signOut} /> : null}
                </>
              ) : (
                <li>
                  <FormModel
                    name="Login"
                    cs="header-show-login-btn"
                    showmsg={showLoginSucces}
                    closemsg={closeLoginSucces}
                  />
                </li>
              )}
            </ul>
          </nav>
          {successMsg ? <SuccessfullMsg close={closeLoginSucces} /> : null}
        </>
      ) : null}
    </>
  );
};

function SuccessfullMsg(props) {
  return (
    <div className="successmsgbox">
      <p>Login successfully!</p>
      <CloseIcon
        onClick={props.close}
        style={{ marginLeft: "5px", paddingLeft: "5px", cursor: "pointer" }}
      />
    </div>
  );
}

function UserprofileDropDown(props) {
  var user = firebase.auth().currentUser;

  const [userimg, setuserimg] = useState({
    saved: false,
    userimage: "",
    imgname: "",
  });
  const [editForm, setEditForm] = useState(false);
  const [useMetaDetails, setUserMetaDetails] = useState({
    userName: "",
    address: "",
  });
  const [crUser, setcrUser] = useState({
    userName: "",
    address: "",
  });

  useState(() => {
    getPreviousData();
  }, []);

  function logout() {
    firebase.auth().signOut();
  }

  const getuserimg = () => {
    var ImgName,
      reader,
      files = [];

    var input = document.createElement("input");
    input.type = "file";

    input.onchange = (e) => {
      files = e.target.files;
      ImgName = e.target.files[0].name;
      setuserimg({
        saved: true,
        userimage: files[0],
        imgname: ImgName,
      });
      reader = new FileReader();
      reader.onload = function () {
        document.getElementById("userimg").src = reader.result;
      };
      reader.readAsDataURL(files[0]);
    };
    input.click();

    //
  };

  const saveuserimage = () => {
    var uploadTask = firebase
      .storage()
      .ref("usersImages/" + userimg.imgname)
      .put(userimg.userimage);
    uploadTask.on(
      "state_changed",
      function (snapshot) {
        var progress = Math.floor(
          (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        );
        document.getElementById("imgupploadingprogress").innerHTML =
          progress + " %";
      },
      function (error) {
        alert("Error occurred while Saving Images!");
      },
      function () {
        //uploading to Database
        setuserimg({ saved: false, userimage: "", imgname: "" });
        uploadTask.snapshot.ref.getDownloadURL().then(function (url) {
          user
            .updateProfile({ photoURL: url })
            .then(function () {
              document.getElementById("imgupploadingprogress").innerHTML = "";
              alert("Image Changed Successfully!");
              firebase
                .database()
                .ref("users")
                .child(user.uid)
                .update({ userProfile: url });
            })
            .catch(function (error) {
              alert("Image Changed Failed!");
            });
        });
      }
    );
  };

  const setEditUserForm = () => {
    if (editForm) {
      setEditForm(false);
      setUserMetaDetails({
        userName: "",
        address: "",
        phone: "",
      });
    } else {
      setEditForm(true);
      getPreviousData();
    }
  };
  const handleUserFormDetails = (event) => {
    setUserMetaDetails({
      ...useMetaDetails,
      [event.target.name]: event.target.value,
    });
    console.log(event);
  };

  function getPreviousData() {
    let dbRef = firebase.database().ref("users");
    dbRef
      .child(user.uid)
      .get()
      .then((snapshot) => {
        if (snapshot.exists()) {
          setUserMetaDetails(snapshot.val());
          setcrUser(snapshot.val());
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }

  const changeUSerData = (e) => {
    e.preventDefault();
    let [na, ad, ph] = [
      useMetaDetails.userName.trim(),
      useMetaDetails.address.trim(),
      useMetaDetails.phone.trim(),
    ];
    let [uName, addr, phone] = [
      na.split(" ").join(""),
      ad.split(" ").join(""),
      ph.split(" ").join(""),
    ];

    if (uName.length >= 3 && addr.length >= 10 && phone.length >= 11) {
      firebase.database().ref("users").child(user.uid).update({
        userName: useMetaDetails.userName,
        address: useMetaDetails.address,
        phone: useMetaDetails.phone,
      });
      user
        .updateProfile({
          displayName: useMetaDetails.userName,
        })
        .then(function () {
          console.log("successfully updated!");
          console.log(user);
        })
        .catch(function (error) {
          alert(error.message);
        });

      var errMsg = document.getElementById("updErrMsg");
      errMsg.innerHTML = "";
      setEditUserForm();
      getPreviousData();
      alert("updated Profile!");
    } else {
      var errMsg = document.getElementById("updErrMsg");
      errMsg.innerHTML =
        "Please Fill the form correctly username length must be above then 3 characters and address 10 and phone 11";
    }
  };

  return (
    <>
      <div className="user_profile_model">
        <span className="notch"></span>
        <div className="user_about_details_popup">
          <figure>
            {user ? (
              user.photoURL ? (
                <img
                  onClick={getuserimg}
                  title="Upload image"
                  id="userimg"
                  src={user.photoURL}
                  alt="userimage"
                />
              ) : (
                <img
                  onClick={getuserimg}
                  title="Upload image"
                  id="userimg"
                  src={defaultuserimg}
                  alt="avatar"
                />
              )
            ) : null}
            {userimg.saved === true ? (
              <span
                color={"green"}
                onClick={saveuserimage}
                style={{
                  display: "block",
                  marginTop: "10px",
                  fontSize: "12px",
                  color: "green",
                  cursor: "pointer",
                }}
              >
                save profile
              </span>
            ) : null}
            <span
              style={{
                display: "block",
                marginTop: "10px",
                fontSize: "12px",
                color: "green",
                cursor: "pointer",
                width: "100%",
                textAlign: "center",
              }}
              id="imgupploadingprogress"
            ></span>
          </figure>

          <div className="userMeta">
            <span>Hello</span>
            {user ? <h3> {crUser.userName} </h3> : <h3>Unkown user</h3>}
            <button onClick={setEditUserForm}>
              <EditOutlinedIcon fontSize="small" />
              {editForm ? "Cancel" : "Edit profile"}
            </button>
          </div>
        </div>
        <div
          style={{ fontSize: "12px", lineHeight: "18p", padding: "10px 12px" }}
        >
          <div>
            {editForm ? (
              <form onSubmit={changeUSerData}>
                <div>
                  <label htmlFor="userName">UserName: </label>
                  <input
                    type="text"
                    value={useMetaDetails.userName}
                    onChange={(e) => handleUserFormDetails(e)}
                    placeholder="userName"
                    name="userName"
                  />
                </div>
                <br />
                <div>
                  <label htmlFor="address">Address: </label>
                  <input
                    type="Text"
                    value={useMetaDetails.address}
                    onChange={(e) => handleUserFormDetails(e)}
                    placeholder="Address"
                    name="address"
                  />
                </div>
                <div>
                  <label htmlFor="phone">Phone: </label>
                  <input
                    type="text"
                    value={useMetaDetails.phone}
                    onChange={(e) => handleUserFormDetails(e)}
                    placeholder="Phone"
                    name="phone"
                  />
                </div>
                <div>
                  <p id="updErrMsg" style={{ color: "red" }}></p>
                </div>
                <div>
                  <input type="submit" value="Update Profile" />
                </div>
              </form>
            ) : null}
          </div>
          <span>
            MR AUTOMOTIVE is built on trust. Help other people get to know you.
            Tell them about the things you like.
          </span>
        </div>
        <div className="logout_btn_sec">
          <button>
            <svg
              width="23px"
              height="23px"
              viewBox="0 0 1024 1024"
              fill="#002f34"
            >
              <path d="M128 85.333l-42.667 42.667v768l42.667 42.667h768l42.667-42.667v-213.333l-42.667-42.667-42.667 42.667v170.667h-682.667v-682.667h682.667v170.667l42.667 42.667 42.667-42.667v-213.333l-42.667-42.667h-768zM494.336 298.667l-183.168 183.168v60.331l183.168 183.168h60.331v-60.331l-110.336-110.336h323.669l42.667-42.667-42.667-42.667h-323.669l110.336-110.336v-60.331h-60.331z"></path>
            </svg>
            <span onClick={props.logout}>Logout</span>
          </button>
        </div>
      </div>
    </>
  );
}

const mapStateToProps = (store) => ({
  currentuser: store.currentuser,
});

export default connect(mapStateToProps, null)(withRouter(Header));
