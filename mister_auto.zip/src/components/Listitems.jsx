import React from "react";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import ListSubheader from "@material-ui/core/ListSubheader";
import DashboardIcon from "@material-ui/icons/Dashboard";
import ShoppingCartIcon from "@material-ui/icons/ShoppingCart";
import PeopleIcon from "@material-ui/icons/People";
import BarChartIcon from "@material-ui/icons/BarChart";
import LayersIcon from "@material-ui/icons/Layers";
import AssignmentIcon from "@material-ui/icons/Assignment";
import { Link } from "react-router-dom";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Typography from "@material-ui/core/Typography";

export default function Listitems(props) {
  const [value, setValue] = React.useState(0);
  //   const [users, setUsers] = React.useState([
  //     { name: "sufy", age: 20 },
  //     { name: "hamza", age: 12 },
  //   ]);
  //   const [orders, setOrders] = React.useState([
  //     { prod: "panther", price: 2000 },
  //     { prod: "service", price: 1200 },
  //   ]);
  //   const handleChange = (event, newValue) => {
  //     setValue(newValue);
  //     console.log(newValue);
  //   };
  return (
    <div>
      <Tabs
        orientation="vertical"
        variant="scrollable"
        value={props.value}
        onChange={props.handleChange}
        aria-label="Vertical tabs example"
        variant="fullWidth"
        indicatorColor="primary"
        textColor="primary"
      >
        <Tab
          className="sidebarTabs"
          icon={<DashboardIcon />}
          label="Dashboard"
        />
        <Tab icons={<ShoppingCartIcon />} label="Orders" />

        <Tab icon={<PeopleIcon />} label="Users" />
      </Tabs>

      <List>
        <ListItem>
          <ListItemIcon>
            <DashboardIcon />
          </ListItemIcon>
          <ListItemText>Go to Web</ListItemText>
        </ListItem>
      </List>
    </div>
  );
}
