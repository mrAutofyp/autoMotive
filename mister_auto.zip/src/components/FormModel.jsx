import React, { useState } from "react";
import Button from "@material-ui/core/Button";
import MultipleLoginForms from "./MulipleLoginForms";

export default function FormModel(props) {
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <Button
        variant="contained"
        color="primary"
        size="small"
        // className={props.cs}
        onClick={handleClickOpen}
      >
        {props.name}
      </Button>
      <MultipleLoginForms
        open={open}
        onClose={handleClose}
        againopen={handleClickOpen}
        closemsg={props.closemsg}
        showmsg={props.showmsg}
      />
    </div>
  );
}
