import React from "react";
import CloseIcon from "@material-ui/icons/Close";
import { connect } from "react-redux";
import { closeSuccessMsg, check_current_user } from "../store/action/action";

function SweatMsg(props) {
  console.log(props.sucessMsg);
  const close = () => {
    props.check_current_user();
  };
  return (
    <div className="successmsgbox">
      <p>Login successfully!</p>
      <CloseIcon
        onClick={close}
        style={{ marginLeft: "5px", paddingLeft: "5px", cursor: "pointer" }}
      />
    </div>
  );
}

const mapStateToProps = (store) => ({
  sucessMsg: store.sucessMsg,
});

const mapDispatchToProps = (dispatch) => ({
  closeSuccessMsg: () => dispatch(closeSuccessMsg),
  check_current_user: () => dispatch(check_current_user),
});

export default connect(mapStateToProps, mapDispatchToProps)(SweatMsg);
